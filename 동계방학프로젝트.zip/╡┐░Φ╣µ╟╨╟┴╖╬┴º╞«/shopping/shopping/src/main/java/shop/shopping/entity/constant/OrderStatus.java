package shop.shopping.entity.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
