package shop.shopping.entity.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
