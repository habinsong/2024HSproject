package shop.shopping.entity.constant;

public enum RepImgYn {
    Y, N
}
