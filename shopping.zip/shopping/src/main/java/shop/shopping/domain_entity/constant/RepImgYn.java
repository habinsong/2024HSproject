package shop.shopping.domain_entity.constant;

public enum RepImgYn {
    Y, N
}
