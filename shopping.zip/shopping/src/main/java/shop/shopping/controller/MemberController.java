package shop.shopping.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import shop.shopping.domain_entity.Member;
import shop.shopping.service.MemberService;

@Controller
public class MemberController {

    private final MemberService memberService;

    @Autowired
    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/members/login")
    public String memberlogin() {
        return "members/login";
    }

    @PostMapping("/members/login")
    public String login(MemberLogin login, HttpSession session) {
        MemberLogin log = memberService.login(login);
        if(log!=null) {
            session.setAttribute("LoginVo", log);
            System.out.println("로그인된 아이디 = "+log.getId());
            return "redirect:/";
        }
        else{
            System.out.println("로그인실패");
            return "redirect:/members/login";
        }
    }

    @GetMapping("/members/new")
    public String createForm() {
        return "members/createMemberForm";
    }

    @PostMapping("/members/new")
    public String create(MemberForm form) {
        Member member = new Member();
        member.setId(form.getId());
        member.setPassword(form.getPassword());
        member.setName(form.getName());
        member.setEmail(form.getEmail());
        member.setPhoneNum(form.getPhoneNum());

        System.out.println("Id = "+member.getId());
        System.out.println("Password = "+member.getPassword());
        System.out.println("Name = "+member.getName());
        System.out.println("Email = "+member.getEmail());
        System.out.println("PhoneNum = "+member.getPhoneNum());

        memberService.join(member);

        return "redirect:/";
    }

    @GetMapping("/members/Mypage")
    public String EditInfo() {
        return "members/my_page";
    }



}
