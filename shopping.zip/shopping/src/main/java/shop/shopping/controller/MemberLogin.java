package shop.shopping.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberLogin {
    private String id;
    private String password;

}
