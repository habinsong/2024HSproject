package shop.shopping.domain_entity.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
