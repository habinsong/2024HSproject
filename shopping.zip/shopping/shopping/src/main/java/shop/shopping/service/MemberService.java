package shop.shopping.service;

import jakarta.transaction.Transactional;
import shop.shopping.domain_entity.Member;
import shop.shopping.repository.MemberRepository;

@Transactional
public class MemberService {
    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    public String join(Member member) {

        validateDuplicateMemberById(member); //중복 회원 검증
        validateDuplicateMemberByphoneNum(member);
        memberRepository.save(member);
        return member.getId();
    }

    private void validateDuplicateMemberById(Member member) {
        memberRepository.findById(member.getName())
                .ifPresent(m -> {
                    throw new IllegalStateException("이미 존재하는 아이디입니다.");
                });
    }

    private void validateDuplicateMemberByphoneNum(Member member) {
        memberRepository.findById(member.getPhoneNum())
                .ifPresent(m -> {
                    throw new IllegalStateException("이미 가입된 핸드폰 번호입니다.");
                });
    }




}
