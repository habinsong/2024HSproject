package shop.shopping.controller;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckPassword {
    private String password;
}
