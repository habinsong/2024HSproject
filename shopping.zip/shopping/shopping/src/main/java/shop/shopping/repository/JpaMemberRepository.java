package shop.shopping.repository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import shop.shopping.domain_entity.Member;

import java.util.List;
import java.util.Optional;

@Repository
public class JpaMemberRepository implements MemberRepository{

    @PersistenceContext
    private EntityManager em;

    public Member save(Member member) {
        em.persist(member);
        return member;
    }

    @Override
    public Optional<Member> findById(String  id) {
        Member member = em.find(Member.class, id);
        return Optional.ofNullable(member);
    }

    @Override
    public Optional<Member> findByPhoneNum(String phoneNum) {
        List<Member> result = em.createQuery("select m from Member m where m.phoneNum = :phoneNum", Member.class)
                .setParameter("phoneNum", phoneNum)
                .getResultList();

        return result.stream().findAny();
    }

    @Override
    public Optional<Member> findByPassword(String password) {
        List<Member> result = em.createQuery("select m from Member m where m.password = :password", Member.class)
                .setParameter("password", password)
                .getResultList();

        return result.stream().findAny();
    }




}
