package shop.shopping.domain_entity.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
